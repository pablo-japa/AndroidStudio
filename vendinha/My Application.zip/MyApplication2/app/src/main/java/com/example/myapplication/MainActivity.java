package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    double morango, banana, melancia, melao;
    CheckBox cb_banana, cb_melancia, cb_melao, cb_morango;
    EditText edt_morango, edt_banana, edt_melancia, edt_melao;
    TextView txtV_valor;
    Button btn_calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_banana = findViewById(R.id.cb_banana);
        cb_morango = findViewById(R.id.cb_morango);
        cb_melao = findViewById(R.id.cb_melao);
        cb_melancia = findViewById(R.id.cb_melancia);

        edt_banana = findViewById(R.id.edt_banana);
        edt_melancia = findViewById(R.id.edt_melancia);
        edt_morango = findViewById(R.id.edt_morango);
        edt_melao = findViewById(R.id.edt_melao);
        


        txtV_valor = findViewById(R.id.txtV_valor);

        btn_calcular = findViewById(R.id.btn_calcular);
    }
}