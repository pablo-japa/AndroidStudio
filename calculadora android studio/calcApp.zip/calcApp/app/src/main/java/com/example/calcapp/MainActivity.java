package com.example.calcapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    double n1, n2, resultado;
    EditText edt_n1 = (EditText) findViewById(R.id.edt_n1);
    EditText edt_n2 = (EditText) findViewById(R.id.edt_n2);
    TextView txtV_resultado = (TextView) findViewById(R.id.txtV_resultado);
    Button btn_soma = (Button) findViewById(R.id.btn_soma);
    Button btn_subtracao = (Button) findViewById(R.id.btn_substracao);
    Button btn_divisao = (Button) findViewById(R.id.btn_divisao);
    Button btn_multiplicacao = (Button) findViewById(R.id.btn_multiplicacao);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void soma(View view) {
        n1 = Double.parseDouble(edt_n1.getText().toString());
        n2 = Double.parseDouble(edt_n2.getText().toString());
        resultado = n1 + n2;

    }

    public void subtracao(View view) {
        n1 = Double.parseDouble(edt_n1.getText().toString());
        n2 = Double.parseDouble(edt_n2.getText().toString());
        resultado = n1 - n2;
    }

    public void divisao(View view) {
        n1 = Double.parseDouble(edt_n1.getText().toString());
        n2 = Double.parseDouble(edt_n2.getText().toString());
        resultado = n1 / n2;
    }

    public void multiplicacao(View view) {
        n1 = Double.parseDouble(edt_n1.getText().toString());
        n2 = Double.parseDouble(edt_n2.getText().toString());
        resultado = n1 * n2;
    }
}