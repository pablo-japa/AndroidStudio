package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_cadastrar=(Button)findViewById(R.id.btn_cadastrar);
        EditText edt_Nome=(EditText)findViewById(R.id.edt_Nome);
        EditText edt_sobrenome=(EditText)findViewById(R.id.edt_sobrenome);
        EditText edt_endereco=(EditText)findViewById(R.id.edt_endereco);
        EditText edt_telefone=(EditText)findViewById(R.id.edt_telefone);
        TextView txtV_nome=(TextView)findViewById(R.id.txtV_nome);
        TextView txtV_sobrenome=(TextView)findViewById(R.id.txtV_sobrenome);
        TextView txtV_endereco=(TextView)findViewById(R.id.txtV_endereco);
        TextView txtV_telefone=(TextView)findViewById(R.id.txtV_telefone);
        TextView txtV_mensagem=(TextView)findViewById(R.id.txtV_mensagem);

        btn_cadastrar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String nome = edt_Nome.getText().toString();
                String sobrenome = edt_sobrenome.getText().toString();
                String endereco = edt_endereco.getText().toString();
                String telefone = edt_telefone.getText().toString();
                ;

                edt_Nome.setText("");
                edt_sobrenome.setText("");
                edt_endereco.setText("");
                edt_telefone.setText("");

                if (nome.isEmpty() || sobrenome.isEmpty() || endereco.isEmpty() || telefone.isEmpty()) {

                    txtV_mensagem.setText("Por favor, preencha todos os campos!");
                } else {

                    txtV_nome.setText(nome);
                    txtV_sobrenome.setText(sobrenome);
                    txtV_endereco.setText(endereco);
                    txtV_telefone.setText(telefone);

                    edt_Nome.setText("");
                    edt_sobrenome.setText("");
                    edt_endereco.setText("");
                    edt_telefone.setText("");

                    txtV_mensagem.setText("Cadastro concluido");
                }
            }

        });





    }
}